A Pen created at CodePen.io. You can find this one at http://codepen.io/kyleledbetter/pen/gbQOaV.

 A starter app with sidenav, icons, tabs, floating action button, and  a list of items.

Forked from [Angular Material Basic App](http://codepen.io/marcysutton/pen/OPbpKm/).